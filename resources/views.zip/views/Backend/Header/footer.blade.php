<footer class="main-footer">
    <div class="footer-left">
      <a href="">Admin Panel</a></a>
    </div>
    <div class="footer-right">
    </div>
  </footer>