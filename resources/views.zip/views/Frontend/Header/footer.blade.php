

<!--<style>-->
    
<!--     .copy-right {-->
<!--            background-color: #f1f1f1;-->
<!--            text-align: center;-->
<!--            padding: 10px 0;-->
<!--            width: 100%;-->
<!--            position: fixed;-->
<!--            bottom: 0;-->
<!--        }-->
<!--    </style>-->


<!--<div class="copy-right">-->
<!--    <div class="">-->
<!--        <div class="row">-->
<!--            <div class="col-md-12 col-sm-12 text-center" style="background-color:black">-->
<!--                <p></p>-->
<!--                <p style="color:#fff; ">Powered By <a href="https://mdhp.in/" target="_blank" style="color:inherit"><strong>MDHP</strong> </a></p>-->
<!--            </div>-->
<!--        </div><!--./row-->-->
<!--    </div><!--./container-->-->
<!--</div>-->



<style>
    
     .copy-right {
            background-color: #f1f1f1;
            text-align: center;
            padding: 2px 0;
            width: 100%;
            position: fixed;
            bottom: 0;
        }
    </style>


<div class="copy-right">
    
        <div class="row">
            <div class="col-md-12 col-sm-12 text-center" style="background-color:black">
                
                <span style="color:#fff; ">Powered By <a href="https://mdhp.in/" target="_blank" style="color:inherit"><strong>MDHP</strong> </a></span>
            </div>
        </div><!--./row-->
   
</div>

    

      <script>
        toastr.error();
toastr.success();
toastr.info();
toastr.warning();
      </script>
     
</body>
</html>