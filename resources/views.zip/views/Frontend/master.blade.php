
@include('Frontend.Header.header')

@yield('BodyContent')

@include('Frontend.Header.footer')