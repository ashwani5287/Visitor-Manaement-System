@extends('Frontend.master')
@section('title','Online Visitor System')
@section('BodyContent')

    

   
    
    <style>
        .login {
            float: right;
            font-weight: bold;
            text-decoration: none;
        }

        .containers {
            margin-top:200px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-size: cover;
            background-position: center;
        }

        .firstMethod {
            border: 1px solid rgb(0, 0, 0);
            border-radius: 8px;
            box-shadow: 3px 4px 8px rgba(48, 47, 47, 0.3); 
            height: 30vh;
            width: 30%;
            background-color: rgb(188, 186, 186);
            opacity: 0.8;
            padding: 20px; 
            box-sizing: border-box;
        }

        .input-group {
            margin-bottom: 15px; 
            max-width: 300px;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: rgb(0, 0, 0);
        }

        .form-control {
            border: 1px solid rgb(41, 40, 40);
           
            width: 100%; 
            box-sizing: border-box; 
            border-radius: 2px;
        }

        @media (max-width: 1200px) {
            .firstMethod {
                width: 40%;
            }
        }

        @media (max-width: 768px) {
            .firstMethod {
                width: 80%;
            }
        }

        @media (max-width: 480px) {
            .firstMethod {
                width: 100%;
                height: auto;
            }

            .containers {
                padding: 20px;
                
            }
        }
    </style>



    <div class="containers">
        <div class="firstMethod">
            <form action="{{ route('front.Checkexistingregister') }}" method="post" id="checkForm" class="text-center">
                @csrf
                <h5>Enter Mobile Number</h5>
                <div class="input-group">
                    <label for="mobileNumber" class="visually-hidden">Mobile Number</label>
                    <input type="text" id="mobileNumber" name="Mobile" autocomplete="off" class="form-control form-control outline-dark rounded" placeholder="Mobile Number" aria-label="Mobile Number" aria-describedby="button-addon2">
                </div>
                <button class="btn btn-danger" type="submit" name="checkForm1" id="button-addon2">Submit</button>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $("#checkForm").submit(function (e) { 
                var mobile = $("#mobileNumber").val();
                if (mobile === "" || isNaN(mobile) || mobile.length !== 10) {
                    alert("Please enter a valid 10-digit mobile number.");
                    e.preventDefault();
                } else {
                    $("#mobileNumber").val(mobile); 
                }
            });
        });
    </script>



    
@endsection